// Generated from d:/egyetem/msc/dipterv/rubiks-cube/backend/grammars/AlgorithmParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class AlgorithmParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ALL=1, ANY=2, BRANCHES=3, CONSECUTIVE=4, DO=5, GOAL=6, HELPERS=7, IF=8, 
		NONE=9, PIECE=10, POS=11, POSITION=12, PREPARE=13, RUNS=14, STEP=15, STEPS=16, 
		COLON=17, COMMA=18, QUESTIONMARK=19, PRIME=20, LPAREN=21, RPAREN=22, LBRACKET=23, 
		RBRACKET=24, AND=25, OR=26, NOT=27, NUMBER=28, WORD=29, LINE_COMMENT=30, 
		BLOCK_COMMENT=31, WS=32;
	public static final int
		RULE_algorithmFile = 0, RULE_helpers = 1, RULE_helperLine = 2, RULE_steps = 3, 
		RULE_step = 4, RULE_stepLine = 5, RULE_goal = 6, RULE_runs = 7, RULE_branches = 8, 
		RULE_doDef = 9, RULE_branch = 10, RULE_ifBranch = 11, RULE_prepareBranch = 12, 
		RULE_consecutive = 13, RULE_algorithm = 14, RULE_turn = 15, RULE_boolExpr = 16, 
		RULE_unaryOp = 17, RULE_binaryOp = 18, RULE_expr = 19, RULE_unaryExpr = 20, 
		RULE_binaryExpr = 21, RULE_functionalExpr = 22, RULE_function = 23, RULE_parameter = 24, 
		RULE_singleNode = 25, RULE_node = 26, RULE_piece = 27, RULE_position = 28, 
		RULE_coord = 29, RULE_list = 30, RULE_sides = 31, RULE_side = 32;
	private static String[] makeRuleNames() {
		return new String[] {
			"algorithmFile", "helpers", "helperLine", "steps", "step", "stepLine", 
			"goal", "runs", "branches", "doDef", "branch", "ifBranch", "prepareBranch", 
			"consecutive", "algorithm", "turn", "boolExpr", "unaryOp", "binaryOp", 
			"expr", "unaryExpr", "binaryExpr", "functionalExpr", "function", "parameter", 
			"singleNode", "node", "piece", "position", "coord", "list", "sides", 
			"side"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'all'", "'any'", "'branches'", "'consecutive'", "'do'", "'goal'", 
			"'helpers'", "'if'", "'none'", "'piece'", "'pos'", "'position'", "'prepare'", 
			"'runs'", "'step'", "'steps'", "':'", "','", "'?'", "'''", "'('", "')'", 
			"'['", "']'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ALL", "ANY", "BRANCHES", "CONSECUTIVE", "DO", "GOAL", "HELPERS", 
			"IF", "NONE", "PIECE", "POS", "POSITION", "PREPARE", "RUNS", "STEP", 
			"STEPS", "COLON", "COMMA", "QUESTIONMARK", "PRIME", "LPAREN", "RPAREN", 
			"LBRACKET", "RBRACKET", "AND", "OR", "NOT", "NUMBER", "WORD", "LINE_COMMENT", 
			"BLOCK_COMMENT", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "AlgorithmParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public AlgorithmParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlgorithmFileContext extends ParserRuleContext {
		public StepsContext steps() {
			return getRuleContext(StepsContext.class,0);
		}
		public TerminalNode EOF() { return getToken(AlgorithmParser.EOF, 0); }
		public HelpersContext helpers() {
			return getRuleContext(HelpersContext.class,0);
		}
		public AlgorithmFileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_algorithmFile; }
	}

	public final AlgorithmFileContext algorithmFile() throws RecognitionException {
		AlgorithmFileContext _localctx = new AlgorithmFileContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_algorithmFile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(67);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HELPERS) {
				{
				setState(66);
				helpers();
				}
			}

			setState(69);
			steps();
			setState(70);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HelpersContext extends ParserRuleContext {
		public TerminalNode HELPERS() { return getToken(AlgorithmParser.HELPERS, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public List<HelperLineContext> helperLine() {
			return getRuleContexts(HelperLineContext.class);
		}
		public HelperLineContext helperLine(int i) {
			return getRuleContext(HelperLineContext.class,i);
		}
		public HelpersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_helpers; }
	}

	public final HelpersContext helpers() throws RecognitionException {
		HelpersContext _localctx = new HelpersContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_helpers);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(72);
			match(HELPERS);
			setState(73);
			match(COLON);
			setState(75); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(74);
				helperLine();
				}
				}
				setState(77); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WORD );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class HelperLineContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public AlgorithmContext algorithm() {
			return getRuleContext(AlgorithmContext.class,0);
		}
		public HelperLineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_helperLine; }
	}

	public final HelperLineContext helperLine() throws RecognitionException {
		HelperLineContext _localctx = new HelperLineContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_helperLine);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			match(WORD);
			setState(80);
			match(COLON);
			setState(81);
			algorithm();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StepsContext extends ParserRuleContext {
		public TerminalNode STEPS() { return getToken(AlgorithmParser.STEPS, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public List<StepContext> step() {
			return getRuleContexts(StepContext.class);
		}
		public StepContext step(int i) {
			return getRuleContext(StepContext.class,i);
		}
		public StepsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_steps; }
	}

	public final StepsContext steps() throws RecognitionException {
		StepsContext _localctx = new StepsContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_steps);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(83);
			match(STEPS);
			setState(84);
			match(COLON);
			setState(88);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==STEP) {
				{
				{
				setState(85);
				step();
				}
				}
				setState(90);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StepContext extends ParserRuleContext {
		public TerminalNode STEP() { return getToken(AlgorithmParser.STEP, 0); }
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public List<StepLineContext> stepLine() {
			return getRuleContexts(StepLineContext.class);
		}
		public StepLineContext stepLine(int i) {
			return getRuleContext(StepLineContext.class,i);
		}
		public StepContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_step; }
	}

	public final StepContext step() throws RecognitionException {
		StepContext _localctx = new StepContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_step);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(91);
			match(STEP);
			setState(92);
			match(WORD);
			setState(93);
			match(COLON);
			setState(97);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 16616L) != 0)) {
				{
				{
				setState(94);
				stepLine();
				}
				}
				setState(99);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StepLineContext extends ParserRuleContext {
		public GoalContext goal() {
			return getRuleContext(GoalContext.class,0);
		}
		public HelpersContext helpers() {
			return getRuleContext(HelpersContext.class,0);
		}
		public RunsContext runs() {
			return getRuleContext(RunsContext.class,0);
		}
		public BranchesContext branches() {
			return getRuleContext(BranchesContext.class,0);
		}
		public DoDefContext doDef() {
			return getRuleContext(DoDefContext.class,0);
		}
		public StepLineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stepLine; }
	}

	public final StepLineContext stepLine() throws RecognitionException {
		StepLineContext _localctx = new StepLineContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_stepLine);
		try {
			setState(105);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case GOAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(100);
				goal();
				}
				break;
			case HELPERS:
				enterOuterAlt(_localctx, 2);
				{
				setState(101);
				helpers();
				}
				break;
			case RUNS:
				enterOuterAlt(_localctx, 3);
				{
				setState(102);
				runs();
				}
				break;
			case BRANCHES:
				enterOuterAlt(_localctx, 4);
				{
				setState(103);
				branches();
				}
				break;
			case DO:
				enterOuterAlt(_localctx, 5);
				{
				setState(104);
				doDef();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class GoalContext extends ParserRuleContext {
		public TerminalNode GOAL() { return getToken(AlgorithmParser.GOAL, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public BoolExprContext boolExpr() {
			return getRuleContext(BoolExprContext.class,0);
		}
		public GoalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_goal; }
	}

	public final GoalContext goal() throws RecognitionException {
		GoalContext _localctx = new GoalContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_goal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(107);
			match(GOAL);
			setState(108);
			match(COLON);
			setState(109);
			boolExpr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RunsContext extends ParserRuleContext {
		public TerminalNode RUNS() { return getToken(AlgorithmParser.RUNS, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public TerminalNode NUMBER() { return getToken(AlgorithmParser.NUMBER, 0); }
		public RunsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_runs; }
	}

	public final RunsContext runs() throws RecognitionException {
		RunsContext _localctx = new RunsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_runs);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(111);
			match(RUNS);
			setState(112);
			match(COLON);
			setState(113);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BranchesContext extends ParserRuleContext {
		public TerminalNode BRANCHES() { return getToken(AlgorithmParser.BRANCHES, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public List<BranchContext> branch() {
			return getRuleContexts(BranchContext.class);
		}
		public BranchContext branch(int i) {
			return getRuleContext(BranchContext.class,i);
		}
		public BranchesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_branches; }
	}

	public final BranchesContext branches() throws RecognitionException {
		BranchesContext _localctx = new BranchesContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_branches);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			match(BRANCHES);
			setState(116);
			match(COLON);
			setState(118); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(117);
				branch();
				}
				}
				setState(120); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==IF || _la==PREPARE );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DoDefContext extends ParserRuleContext {
		public TerminalNode DO() { return getToken(AlgorithmParser.DO, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public AlgorithmContext algorithm() {
			return getRuleContext(AlgorithmContext.class,0);
		}
		public DoDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doDef; }
	}

	public final DoDefContext doDef() throws RecognitionException {
		DoDefContext _localctx = new DoDefContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_doDef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			match(DO);
			setState(123);
			match(COLON);
			setState(124);
			algorithm();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BranchContext extends ParserRuleContext {
		public IfBranchContext ifBranch() {
			return getRuleContext(IfBranchContext.class,0);
		}
		public PrepareBranchContext prepareBranch() {
			return getRuleContext(PrepareBranchContext.class,0);
		}
		public BranchContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_branch; }
	}

	public final BranchContext branch() throws RecognitionException {
		BranchContext _localctx = new BranchContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_branch);
		try {
			setState(128);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IF:
				enterOuterAlt(_localctx, 1);
				{
				setState(126);
				ifBranch();
				}
				break;
			case PREPARE:
				enterOuterAlt(_localctx, 2);
				{
				setState(127);
				prepareBranch();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IfBranchContext extends ParserRuleContext {
		public TerminalNode IF() { return getToken(AlgorithmParser.IF, 0); }
		public BoolExprContext boolExpr() {
			return getRuleContext(BoolExprContext.class,0);
		}
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public DoDefContext doDef() {
			return getRuleContext(DoDefContext.class,0);
		}
		public IfBranchContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifBranch; }
	}

	public final IfBranchContext ifBranch() throws RecognitionException {
		IfBranchContext _localctx = new IfBranchContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_ifBranch);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			match(IF);
			setState(131);
			boolExpr(0);
			setState(132);
			match(COLON);
			setState(133);
			doDef();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrepareBranchContext extends ParserRuleContext {
		public TerminalNode PREPARE() { return getToken(AlgorithmParser.PREPARE, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public AlgorithmContext algorithm() {
			return getRuleContext(AlgorithmContext.class,0);
		}
		public DoDefContext doDef() {
			return getRuleContext(DoDefContext.class,0);
		}
		public ConsecutiveContext consecutive() {
			return getRuleContext(ConsecutiveContext.class,0);
		}
		public PrepareBranchContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prepareBranch; }
	}

	public final PrepareBranchContext prepareBranch() throws RecognitionException {
		PrepareBranchContext _localctx = new PrepareBranchContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_prepareBranch);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(135);
			match(PREPARE);
			setState(136);
			match(COLON);
			setState(141);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				{
				{
				setState(137);
				doDef();
				setState(138);
				consecutive();
				}
				}
				break;
			case 2:
				{
				setState(140);
				algorithm();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConsecutiveContext extends ParserRuleContext {
		public TerminalNode CONSECUTIVE() { return getToken(AlgorithmParser.CONSECUTIVE, 0); }
		public TerminalNode COLON() { return getToken(AlgorithmParser.COLON, 0); }
		public TerminalNode NUMBER() { return getToken(AlgorithmParser.NUMBER, 0); }
		public ConsecutiveContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_consecutive; }
	}

	public final ConsecutiveContext consecutive() throws RecognitionException {
		ConsecutiveContext _localctx = new ConsecutiveContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_consecutive);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(143);
			match(CONSECUTIVE);
			setState(144);
			match(COLON);
			setState(145);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AlgorithmContext extends ParserRuleContext {
		public List<TurnContext> turn() {
			return getRuleContexts(TurnContext.class);
		}
		public TurnContext turn(int i) {
			return getRuleContext(TurnContext.class,i);
		}
		public AlgorithmContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_algorithm; }
	}

	public final AlgorithmContext algorithm() throws RecognitionException {
		AlgorithmContext _localctx = new AlgorithmContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_algorithm);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(150);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(147);
					turn();
					}
					} 
				}
				setState(152);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TurnContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public List<TerminalNode> NUMBER() { return getTokens(AlgorithmParser.NUMBER); }
		public TerminalNode NUMBER(int i) {
			return getToken(AlgorithmParser.NUMBER, i);
		}
		public TerminalNode PRIME() { return getToken(AlgorithmParser.PRIME, 0); }
		public TerminalNode LPAREN() { return getToken(AlgorithmParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(AlgorithmParser.RPAREN, 0); }
		public AlgorithmContext algorithm() {
			return getRuleContext(AlgorithmContext.class,0);
		}
		public TurnContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_turn; }
	}

	public final TurnContext turn() throws RecognitionException {
		TurnContext _localctx = new TurnContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_turn);
		int _la;
		try {
			setState(169);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case WORD:
				enterOuterAlt(_localctx, 1);
				{
				setState(153);
				match(WORD);
				setState(155);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
				case 1:
					{
					setState(154);
					_la = _input.LA(1);
					if ( !(_la==PRIME || _la==NUMBER) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					break;
				}
				}
				break;
			case LPAREN:
				enterOuterAlt(_localctx, 2);
				{
				setState(157);
				match(LPAREN);
				setState(158);
				match(NUMBER);
				setState(159);
				match(WORD);
				setState(161);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==PRIME || _la==NUMBER) {
					{
					setState(160);
					_la = _input.LA(1);
					if ( !(_la==PRIME || _la==NUMBER) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
				}

				setState(163);
				match(RPAREN);
				}
				break;
			case NUMBER:
				enterOuterAlt(_localctx, 3);
				{
				setState(164);
				match(NUMBER);
				setState(165);
				match(LPAREN);
				setState(166);
				algorithm();
				setState(167);
				match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BoolExprContext extends ParserRuleContext {
		public UnaryOpContext unaryOp() {
			return getRuleContext(UnaryOpContext.class,0);
		}
		public List<BoolExprContext> boolExpr() {
			return getRuleContexts(BoolExprContext.class);
		}
		public BoolExprContext boolExpr(int i) {
			return getRuleContext(BoolExprContext.class,i);
		}
		public TerminalNode LPAREN() { return getToken(AlgorithmParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(AlgorithmParser.RPAREN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public BinaryOpContext binaryOp() {
			return getRuleContext(BinaryOpContext.class,0);
		}
		public BoolExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolExpr; }
	}

	public final BoolExprContext boolExpr() throws RecognitionException {
		return boolExpr(0);
	}

	private BoolExprContext boolExpr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		BoolExprContext _localctx = new BoolExprContext(_ctx, _parentState);
		BoolExprContext _prevctx = _localctx;
		int _startState = 32;
		enterRecursionRule(_localctx, 32, RULE_boolExpr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(180);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				{
				setState(172);
				unaryOp();
				setState(173);
				boolExpr(4);
				}
				break;
			case 2:
				{
				setState(175);
				match(LPAREN);
				setState(176);
				boolExpr(0);
				setState(177);
				match(RPAREN);
				}
				break;
			case 3:
				{
				setState(179);
				expr();
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(188);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new BoolExprContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_boolExpr);
					setState(182);
					if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
					setState(183);
					binaryOp();
					setState(184);
					boolExpr(4);
					}
					} 
				}
				setState(190);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UnaryOpContext extends ParserRuleContext {
		public TerminalNode NOT() { return getToken(AlgorithmParser.NOT, 0); }
		public UnaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryOp; }
	}

	public final UnaryOpContext unaryOp() throws RecognitionException {
		UnaryOpContext _localctx = new UnaryOpContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_unaryOp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(191);
			match(NOT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BinaryOpContext extends ParserRuleContext {
		public TerminalNode AND() { return getToken(AlgorithmParser.AND, 0); }
		public TerminalNode OR() { return getToken(AlgorithmParser.OR, 0); }
		public BinaryOpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryOp; }
	}

	public final BinaryOpContext binaryOp() throws RecognitionException {
		BinaryOpContext _localctx = new BinaryOpContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_binaryOp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(193);
			_la = _input.LA(1);
			if ( !(_la==AND || _la==OR) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public FunctionalExprContext functionalExpr() {
			return getRuleContext(FunctionalExprContext.class,0);
		}
		public UnaryExprContext unaryExpr() {
			return getRuleContext(UnaryExprContext.class,0);
		}
		public BinaryExprContext binaryExpr() {
			return getRuleContext(BinaryExprContext.class,0);
		}
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	}

	public final ExprContext expr() throws RecognitionException {
		ExprContext _localctx = new ExprContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_expr);
		try {
			setState(198);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(195);
				functionalExpr();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(196);
				unaryExpr();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(197);
				binaryExpr();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UnaryExprContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public TerminalNode LPAREN() { return getToken(AlgorithmParser.LPAREN, 0); }
		public ParameterContext parameter() {
			return getRuleContext(ParameterContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(AlgorithmParser.RPAREN, 0); }
		public UnaryExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpr; }
	}

	public final UnaryExprContext unaryExpr() throws RecognitionException {
		UnaryExprContext _localctx = new UnaryExprContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_unaryExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			match(WORD);
			setState(201);
			match(LPAREN);
			setState(202);
			parameter();
			setState(203);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BinaryExprContext extends ParserRuleContext {
		public List<ParameterContext> parameter() {
			return getRuleContexts(ParameterContext.class);
		}
		public ParameterContext parameter(int i) {
			return getRuleContext(ParameterContext.class,i);
		}
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public BinaryExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryExpr; }
	}

	public final BinaryExprContext binaryExpr() throws RecognitionException {
		BinaryExprContext _localctx = new BinaryExprContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_binaryExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			parameter();
			setState(206);
			match(WORD);
			setState(207);
			parameter();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionalExprContext extends ParserRuleContext {
		public FunctionContext function() {
			return getRuleContext(FunctionContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(AlgorithmParser.LPAREN, 0); }
		public BoolExprContext boolExpr() {
			return getRuleContext(BoolExprContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(AlgorithmParser.COMMA, 0); }
		public ListContext list() {
			return getRuleContext(ListContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(AlgorithmParser.RPAREN, 0); }
		public FunctionalExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functionalExpr; }
	}

	public final FunctionalExprContext functionalExpr() throws RecognitionException {
		FunctionalExprContext _localctx = new FunctionalExprContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_functionalExpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(209);
			function();
			setState(210);
			match(LPAREN);
			setState(211);
			boolExpr(0);
			setState(212);
			match(COMMA);
			setState(213);
			list();
			setState(214);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FunctionContext extends ParserRuleContext {
		public TerminalNode ALL() { return getToken(AlgorithmParser.ALL, 0); }
		public TerminalNode ANY() { return getToken(AlgorithmParser.ANY, 0); }
		public TerminalNode NONE() { return getToken(AlgorithmParser.NONE, 0); }
		public FunctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function; }
	}

	public final FunctionContext function() throws RecognitionException {
		FunctionContext _localctx = new FunctionContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(216);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 518L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ParameterContext extends ParserRuleContext {
		public SingleNodeContext singleNode() {
			return getRuleContext(SingleNodeContext.class,0);
		}
		public NodeContext node() {
			return getRuleContext(NodeContext.class,0);
		}
		public PieceContext piece() {
			return getRuleContext(PieceContext.class,0);
		}
		public PositionContext position() {
			return getRuleContext(PositionContext.class,0);
		}
		public CoordContext coord() {
			return getRuleContext(CoordContext.class,0);
		}
		public ListContext list() {
			return getRuleContext(ListContext.class,0);
		}
		public TerminalNode QUESTIONMARK() { return getToken(AlgorithmParser.QUESTIONMARK, 0); }
		public ParameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parameter; }
	}

	public final ParameterContext parameter() throws RecognitionException {
		ParameterContext _localctx = new ParameterContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_parameter);
		try {
			setState(225);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(218);
				singleNode();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(219);
				node();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(220);
				piece();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(221);
				position();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(222);
				coord();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(223);
				list();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(224);
				match(QUESTIONMARK);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SingleNodeContext extends ParserRuleContext {
		public SidesContext sides() {
			return getRuleContext(SidesContext.class,0);
		}
		public TerminalNode NUMBER() { return getToken(AlgorithmParser.NUMBER, 0); }
		public SingleNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_singleNode; }
	}

	public final SingleNodeContext singleNode() throws RecognitionException {
		SingleNodeContext _localctx = new SingleNodeContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_singleNode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(227);
			sides();
			setState(229);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				{
				setState(228);
				match(NUMBER);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NodeContext extends ParserRuleContext {
		public TerminalNode LPAREN() { return getToken(AlgorithmParser.LPAREN, 0); }
		public SingleNodeContext singleNode() {
			return getRuleContext(SingleNodeContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(AlgorithmParser.RPAREN, 0); }
		public NodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_node; }
	}

	public final NodeContext node() throws RecognitionException {
		NodeContext _localctx = new NodeContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_node);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(231);
			match(LPAREN);
			setState(232);
			singleNode();
			setState(233);
			match(RPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PieceContext extends ParserRuleContext {
		public TerminalNode PIECE() { return getToken(AlgorithmParser.PIECE, 0); }
		public NodeContext node() {
			return getRuleContext(NodeContext.class,0);
		}
		public PieceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_piece; }
	}

	public final PieceContext piece() throws RecognitionException {
		PieceContext _localctx = new PieceContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_piece);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(235);
			match(PIECE);
			setState(236);
			node();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PositionContext extends ParserRuleContext {
		public NodeContext node() {
			return getRuleContext(NodeContext.class,0);
		}
		public TerminalNode POS() { return getToken(AlgorithmParser.POS, 0); }
		public TerminalNode POSITION() { return getToken(AlgorithmParser.POSITION, 0); }
		public PositionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_position; }
	}

	public final PositionContext position() throws RecognitionException {
		PositionContext _localctx = new PositionContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_position);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(238);
			_la = _input.LA(1);
			if ( !(_la==POS || _la==POSITION) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(239);
			node();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CoordContext extends ParserRuleContext {
		public SideContext side() {
			return getRuleContext(SideContext.class,0);
		}
		public List<TerminalNode> NUMBER() { return getTokens(AlgorithmParser.NUMBER); }
		public TerminalNode NUMBER(int i) {
			return getToken(AlgorithmParser.NUMBER, i);
		}
		public CoordContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_coord; }
	}

	public final CoordContext coord() throws RecognitionException {
		CoordContext _localctx = new CoordContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_coord);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(241);
			side();
			setState(242);
			match(NUMBER);
			setState(243);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ListContext extends ParserRuleContext {
		public TerminalNode LBRACKET() { return getToken(AlgorithmParser.LBRACKET, 0); }
		public TerminalNode RBRACKET() { return getToken(AlgorithmParser.RBRACKET, 0); }
		public List<NodeContext> node() {
			return getRuleContexts(NodeContext.class);
		}
		public NodeContext node(int i) {
			return getRuleContext(NodeContext.class,i);
		}
		public List<PieceContext> piece() {
			return getRuleContexts(PieceContext.class);
		}
		public PieceContext piece(int i) {
			return getRuleContext(PieceContext.class,i);
		}
		public List<PositionContext> position() {
			return getRuleContexts(PositionContext.class);
		}
		public PositionContext position(int i) {
			return getRuleContext(PositionContext.class,i);
		}
		public List<CoordContext> coord() {
			return getRuleContexts(CoordContext.class);
		}
		public CoordContext coord(int i) {
			return getRuleContext(CoordContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(AlgorithmParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(AlgorithmParser.COMMA, i);
		}
		public ListContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_list; }
	}

	public final ListContext list() throws RecognitionException {
		ListContext _localctx = new ListContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_list);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(245);
			match(LBRACKET);
			setState(280);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LPAREN:
				{
				{
				setState(246);
				node();
				setState(251);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(247);
					match(COMMA);
					setState(248);
					node();
					}
					}
					setState(253);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				break;
			case PIECE:
				{
				{
				setState(254);
				piece();
				setState(259);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(255);
					match(COMMA);
					setState(256);
					piece();
					}
					}
					setState(261);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				break;
			case POS:
			case POSITION:
			case WORD:
				{
				setState(278);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case POS:
				case POSITION:
					{
					setState(262);
					position();
					setState(267);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(263);
						match(COMMA);
						setState(264);
						position();
						}
						}
						setState(269);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					break;
				case WORD:
					{
					{
					setState(270);
					coord();
					setState(275);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(271);
						match(COMMA);
						setState(272);
						coord();
						}
						}
						setState(277);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(282);
			match(RBRACKET);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SidesContext extends ParserRuleContext {
		public List<SideContext> side() {
			return getRuleContexts(SideContext.class);
		}
		public SideContext side(int i) {
			return getRuleContext(SideContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(AlgorithmParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(AlgorithmParser.COMMA, i);
		}
		public SidesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sides; }
	}

	public final SidesContext sides() throws RecognitionException {
		SidesContext _localctx = new SidesContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_sides);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(284);
			side();
			setState(289);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(285);
					match(COMMA);
					setState(286);
					side();
					}
					} 
				}
				setState(291);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,23,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SideContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(AlgorithmParser.WORD, 0); }
		public SideContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_side; }
	}

	public final SideContext side() throws RecognitionException {
		SideContext _localctx = new SideContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_side);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(292);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 16:
			return boolExpr_sempred((BoolExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean boolExpr_sempred(BoolExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 3);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001 \u0127\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0001\u0000\u0003\u0000D\b\u0000"+
		"\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0004\u0001L\b\u0001\u000b\u0001\f\u0001M\u0001\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0003\u0001\u0003\u0001\u0003\u0005\u0003W\b"+
		"\u0003\n\u0003\f\u0003Z\t\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001"+
		"\u0004\u0005\u0004`\b\u0004\n\u0004\f\u0004c\t\u0004\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005j\b\u0005\u0001"+
		"\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001"+
		"\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0004\bw\b\b\u000b\b\f\bx\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\n\u0001\n\u0003\n\u0081\b\n\u0001\u000b"+
		"\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001"+
		"\f\u0001\f\u0001\f\u0001\f\u0003\f\u008e\b\f\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\u000e\u0005\u000e\u0095\b\u000e\n\u000e\f\u000e\u0098\t\u000e"+
		"\u0001\u000f\u0001\u000f\u0003\u000f\u009c\b\u000f\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0003\u000f\u00a2\b\u000f\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0003\u000f\u00aa\b\u000f"+
		"\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010"+
		"\u0001\u0010\u0001\u0010\u0001\u0010\u0003\u0010\u00b5\b\u0010\u0001\u0010"+
		"\u0001\u0010\u0001\u0010\u0001\u0010\u0005\u0010\u00bb\b\u0010\n\u0010"+
		"\f\u0010\u00be\t\u0010\u0001\u0011\u0001\u0011\u0001\u0012\u0001\u0012"+
		"\u0001\u0013\u0001\u0013\u0001\u0013\u0003\u0013\u00c7\b\u0013\u0001\u0014"+
		"\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0015\u0001\u0015"+
		"\u0001\u0015\u0001\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0016"+
		"\u0001\u0016\u0001\u0016\u0001\u0016\u0001\u0017\u0001\u0017\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0003\u0018\u00e2\b\u0018\u0001\u0019\u0001\u0019\u0003\u0019\u00e6\b"+
		"\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0001\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0001"+
		"\u001e\u0005\u001e\u00fa\b\u001e\n\u001e\f\u001e\u00fd\t\u001e\u0001\u001e"+
		"\u0001\u001e\u0001\u001e\u0005\u001e\u0102\b\u001e\n\u001e\f\u001e\u0105"+
		"\t\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0005\u001e\u010a\b\u001e"+
		"\n\u001e\f\u001e\u010d\t\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0005"+
		"\u001e\u0112\b\u001e\n\u001e\f\u001e\u0115\t\u001e\u0003\u001e\u0117\b"+
		"\u001e\u0003\u001e\u0119\b\u001e\u0001\u001e\u0001\u001e\u0001\u001f\u0001"+
		"\u001f\u0001\u001f\u0005\u001f\u0120\b\u001f\n\u001f\f\u001f\u0123\t\u001f"+
		"\u0001 \u0001 \u0001 \u0000\u0001 !\u0000\u0002\u0004\u0006\b\n\f\u000e"+
		"\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@\u0000"+
		"\u0004\u0002\u0000\u0014\u0014\u001c\u001c\u0001\u0000\u0019\u001a\u0002"+
		"\u0000\u0001\u0002\t\t\u0001\u0000\u000b\f\u0129\u0000C\u0001\u0000\u0000"+
		"\u0000\u0002H\u0001\u0000\u0000\u0000\u0004O\u0001\u0000\u0000\u0000\u0006"+
		"S\u0001\u0000\u0000\u0000\b[\u0001\u0000\u0000\u0000\ni\u0001\u0000\u0000"+
		"\u0000\fk\u0001\u0000\u0000\u0000\u000eo\u0001\u0000\u0000\u0000\u0010"+
		"s\u0001\u0000\u0000\u0000\u0012z\u0001\u0000\u0000\u0000\u0014\u0080\u0001"+
		"\u0000\u0000\u0000\u0016\u0082\u0001\u0000\u0000\u0000\u0018\u0087\u0001"+
		"\u0000\u0000\u0000\u001a\u008f\u0001\u0000\u0000\u0000\u001c\u0096\u0001"+
		"\u0000\u0000\u0000\u001e\u00a9\u0001\u0000\u0000\u0000 \u00b4\u0001\u0000"+
		"\u0000\u0000\"\u00bf\u0001\u0000\u0000\u0000$\u00c1\u0001\u0000\u0000"+
		"\u0000&\u00c6\u0001\u0000\u0000\u0000(\u00c8\u0001\u0000\u0000\u0000*"+
		"\u00cd\u0001\u0000\u0000\u0000,\u00d1\u0001\u0000\u0000\u0000.\u00d8\u0001"+
		"\u0000\u0000\u00000\u00e1\u0001\u0000\u0000\u00002\u00e3\u0001\u0000\u0000"+
		"\u00004\u00e7\u0001\u0000\u0000\u00006\u00eb\u0001\u0000\u0000\u00008"+
		"\u00ee\u0001\u0000\u0000\u0000:\u00f1\u0001\u0000\u0000\u0000<\u00f5\u0001"+
		"\u0000\u0000\u0000>\u011c\u0001\u0000\u0000\u0000@\u0124\u0001\u0000\u0000"+
		"\u0000BD\u0003\u0002\u0001\u0000CB\u0001\u0000\u0000\u0000CD\u0001\u0000"+
		"\u0000\u0000DE\u0001\u0000\u0000\u0000EF\u0003\u0006\u0003\u0000FG\u0005"+
		"\u0000\u0000\u0001G\u0001\u0001\u0000\u0000\u0000HI\u0005\u0007\u0000"+
		"\u0000IK\u0005\u0011\u0000\u0000JL\u0003\u0004\u0002\u0000KJ\u0001\u0000"+
		"\u0000\u0000LM\u0001\u0000\u0000\u0000MK\u0001\u0000\u0000\u0000MN\u0001"+
		"\u0000\u0000\u0000N\u0003\u0001\u0000\u0000\u0000OP\u0005\u001d\u0000"+
		"\u0000PQ\u0005\u0011\u0000\u0000QR\u0003\u001c\u000e\u0000R\u0005\u0001"+
		"\u0000\u0000\u0000ST\u0005\u0010\u0000\u0000TX\u0005\u0011\u0000\u0000"+
		"UW\u0003\b\u0004\u0000VU\u0001\u0000\u0000\u0000WZ\u0001\u0000\u0000\u0000"+
		"XV\u0001\u0000\u0000\u0000XY\u0001\u0000\u0000\u0000Y\u0007\u0001\u0000"+
		"\u0000\u0000ZX\u0001\u0000\u0000\u0000[\\\u0005\u000f\u0000\u0000\\]\u0005"+
		"\u001d\u0000\u0000]a\u0005\u0011\u0000\u0000^`\u0003\n\u0005\u0000_^\u0001"+
		"\u0000\u0000\u0000`c\u0001\u0000\u0000\u0000a_\u0001\u0000\u0000\u0000"+
		"ab\u0001\u0000\u0000\u0000b\t\u0001\u0000\u0000\u0000ca\u0001\u0000\u0000"+
		"\u0000dj\u0003\f\u0006\u0000ej\u0003\u0002\u0001\u0000fj\u0003\u000e\u0007"+
		"\u0000gj\u0003\u0010\b\u0000hj\u0003\u0012\t\u0000id\u0001\u0000\u0000"+
		"\u0000ie\u0001\u0000\u0000\u0000if\u0001\u0000\u0000\u0000ig\u0001\u0000"+
		"\u0000\u0000ih\u0001\u0000\u0000\u0000j\u000b\u0001\u0000\u0000\u0000"+
		"kl\u0005\u0006\u0000\u0000lm\u0005\u0011\u0000\u0000mn\u0003 \u0010\u0000"+
		"n\r\u0001\u0000\u0000\u0000op\u0005\u000e\u0000\u0000pq\u0005\u0011\u0000"+
		"\u0000qr\u0005\u001c\u0000\u0000r\u000f\u0001\u0000\u0000\u0000st\u0005"+
		"\u0003\u0000\u0000tv\u0005\u0011\u0000\u0000uw\u0003\u0014\n\u0000vu\u0001"+
		"\u0000\u0000\u0000wx\u0001\u0000\u0000\u0000xv\u0001\u0000\u0000\u0000"+
		"xy\u0001\u0000\u0000\u0000y\u0011\u0001\u0000\u0000\u0000z{\u0005\u0005"+
		"\u0000\u0000{|\u0005\u0011\u0000\u0000|}\u0003\u001c\u000e\u0000}\u0013"+
		"\u0001\u0000\u0000\u0000~\u0081\u0003\u0016\u000b\u0000\u007f\u0081\u0003"+
		"\u0018\f\u0000\u0080~\u0001\u0000\u0000\u0000\u0080\u007f\u0001\u0000"+
		"\u0000\u0000\u0081\u0015\u0001\u0000\u0000\u0000\u0082\u0083\u0005\b\u0000"+
		"\u0000\u0083\u0084\u0003 \u0010\u0000\u0084\u0085\u0005\u0011\u0000\u0000"+
		"\u0085\u0086\u0003\u0012\t\u0000\u0086\u0017\u0001\u0000\u0000\u0000\u0087"+
		"\u0088\u0005\r\u0000\u0000\u0088\u008d\u0005\u0011\u0000\u0000\u0089\u008a"+
		"\u0003\u0012\t\u0000\u008a\u008b\u0003\u001a\r\u0000\u008b\u008e\u0001"+
		"\u0000\u0000\u0000\u008c\u008e\u0003\u001c\u000e\u0000\u008d\u0089\u0001"+
		"\u0000\u0000\u0000\u008d\u008c\u0001\u0000\u0000\u0000\u008e\u0019\u0001"+
		"\u0000\u0000\u0000\u008f\u0090\u0005\u0004\u0000\u0000\u0090\u0091\u0005"+
		"\u0011\u0000\u0000\u0091\u0092\u0005\u001c\u0000\u0000\u0092\u001b\u0001"+
		"\u0000\u0000\u0000\u0093\u0095\u0003\u001e\u000f\u0000\u0094\u0093\u0001"+
		"\u0000\u0000\u0000\u0095\u0098\u0001\u0000\u0000\u0000\u0096\u0094\u0001"+
		"\u0000\u0000\u0000\u0096\u0097\u0001\u0000\u0000\u0000\u0097\u001d\u0001"+
		"\u0000\u0000\u0000\u0098\u0096\u0001\u0000\u0000\u0000\u0099\u009b\u0005"+
		"\u001d\u0000\u0000\u009a\u009c\u0007\u0000\u0000\u0000\u009b\u009a\u0001"+
		"\u0000\u0000\u0000\u009b\u009c\u0001\u0000\u0000\u0000\u009c\u00aa\u0001"+
		"\u0000\u0000\u0000\u009d\u009e\u0005\u0015\u0000\u0000\u009e\u009f\u0005"+
		"\u001c\u0000\u0000\u009f\u00a1\u0005\u001d\u0000\u0000\u00a0\u00a2\u0007"+
		"\u0000\u0000\u0000\u00a1\u00a0\u0001\u0000\u0000\u0000\u00a1\u00a2\u0001"+
		"\u0000\u0000\u0000\u00a2\u00a3\u0001\u0000\u0000\u0000\u00a3\u00aa\u0005"+
		"\u0016\u0000\u0000\u00a4\u00a5\u0005\u001c\u0000\u0000\u00a5\u00a6\u0005"+
		"\u0015\u0000\u0000\u00a6\u00a7\u0003\u001c\u000e\u0000\u00a7\u00a8\u0005"+
		"\u0016\u0000\u0000\u00a8\u00aa\u0001\u0000\u0000\u0000\u00a9\u0099\u0001"+
		"\u0000\u0000\u0000\u00a9\u009d\u0001\u0000\u0000\u0000\u00a9\u00a4\u0001"+
		"\u0000\u0000\u0000\u00aa\u001f\u0001\u0000\u0000\u0000\u00ab\u00ac\u0006"+
		"\u0010\uffff\uffff\u0000\u00ac\u00ad\u0003\"\u0011\u0000\u00ad\u00ae\u0003"+
		" \u0010\u0004\u00ae\u00b5\u0001\u0000\u0000\u0000\u00af\u00b0\u0005\u0015"+
		"\u0000\u0000\u00b0\u00b1\u0003 \u0010\u0000\u00b1\u00b2\u0005\u0016\u0000"+
		"\u0000\u00b2\u00b5\u0001\u0000\u0000\u0000\u00b3\u00b5\u0003&\u0013\u0000"+
		"\u00b4\u00ab\u0001\u0000\u0000\u0000\u00b4\u00af\u0001\u0000\u0000\u0000"+
		"\u00b4\u00b3\u0001\u0000\u0000\u0000\u00b5\u00bc\u0001\u0000\u0000\u0000"+
		"\u00b6\u00b7\n\u0003\u0000\u0000\u00b7\u00b8\u0003$\u0012\u0000\u00b8"+
		"\u00b9\u0003 \u0010\u0004\u00b9\u00bb\u0001\u0000\u0000\u0000\u00ba\u00b6"+
		"\u0001\u0000\u0000\u0000\u00bb\u00be\u0001\u0000\u0000\u0000\u00bc\u00ba"+
		"\u0001\u0000\u0000\u0000\u00bc\u00bd\u0001\u0000\u0000\u0000\u00bd!\u0001"+
		"\u0000\u0000\u0000\u00be\u00bc\u0001\u0000\u0000\u0000\u00bf\u00c0\u0005"+
		"\u001b\u0000\u0000\u00c0#\u0001\u0000\u0000\u0000\u00c1\u00c2\u0007\u0001"+
		"\u0000\u0000\u00c2%\u0001\u0000\u0000\u0000\u00c3\u00c7\u0003,\u0016\u0000"+
		"\u00c4\u00c7\u0003(\u0014\u0000\u00c5\u00c7\u0003*\u0015\u0000\u00c6\u00c3"+
		"\u0001\u0000\u0000\u0000\u00c6\u00c4\u0001\u0000\u0000\u0000\u00c6\u00c5"+
		"\u0001\u0000\u0000\u0000\u00c7\'\u0001\u0000\u0000\u0000\u00c8\u00c9\u0005"+
		"\u001d\u0000\u0000\u00c9\u00ca\u0005\u0015\u0000\u0000\u00ca\u00cb\u0003"+
		"0\u0018\u0000\u00cb\u00cc\u0005\u0016\u0000\u0000\u00cc)\u0001\u0000\u0000"+
		"\u0000\u00cd\u00ce\u00030\u0018\u0000\u00ce\u00cf\u0005\u001d\u0000\u0000"+
		"\u00cf\u00d0\u00030\u0018\u0000\u00d0+\u0001\u0000\u0000\u0000\u00d1\u00d2"+
		"\u0003.\u0017\u0000\u00d2\u00d3\u0005\u0015\u0000\u0000\u00d3\u00d4\u0003"+
		" \u0010\u0000\u00d4\u00d5\u0005\u0012\u0000\u0000\u00d5\u00d6\u0003<\u001e"+
		"\u0000\u00d6\u00d7\u0005\u0016\u0000\u0000\u00d7-\u0001\u0000\u0000\u0000"+
		"\u00d8\u00d9\u0007\u0002\u0000\u0000\u00d9/\u0001\u0000\u0000\u0000\u00da"+
		"\u00e2\u00032\u0019\u0000\u00db\u00e2\u00034\u001a\u0000\u00dc\u00e2\u0003"+
		"6\u001b\u0000\u00dd\u00e2\u00038\u001c\u0000\u00de\u00e2\u0003:\u001d"+
		"\u0000\u00df\u00e2\u0003<\u001e\u0000\u00e0\u00e2\u0005\u0013\u0000\u0000"+
		"\u00e1\u00da\u0001\u0000\u0000\u0000\u00e1\u00db\u0001\u0000\u0000\u0000"+
		"\u00e1\u00dc\u0001\u0000\u0000\u0000\u00e1\u00dd\u0001\u0000\u0000\u0000"+
		"\u00e1\u00de\u0001\u0000\u0000\u0000\u00e1\u00df\u0001\u0000\u0000\u0000"+
		"\u00e1\u00e0\u0001\u0000\u0000\u0000\u00e21\u0001\u0000\u0000\u0000\u00e3"+
		"\u00e5\u0003>\u001f\u0000\u00e4\u00e6\u0005\u001c\u0000\u0000\u00e5\u00e4"+
		"\u0001\u0000\u0000\u0000\u00e5\u00e6\u0001\u0000\u0000\u0000\u00e63\u0001"+
		"\u0000\u0000\u0000\u00e7\u00e8\u0005\u0015\u0000\u0000\u00e8\u00e9\u0003"+
		"2\u0019\u0000\u00e9\u00ea\u0005\u0016\u0000\u0000\u00ea5\u0001\u0000\u0000"+
		"\u0000\u00eb\u00ec\u0005\n\u0000\u0000\u00ec\u00ed\u00034\u001a\u0000"+
		"\u00ed7\u0001\u0000\u0000\u0000\u00ee\u00ef\u0007\u0003\u0000\u0000\u00ef"+
		"\u00f0\u00034\u001a\u0000\u00f09\u0001\u0000\u0000\u0000\u00f1\u00f2\u0003"+
		"@ \u0000\u00f2\u00f3\u0005\u001c\u0000\u0000\u00f3\u00f4\u0005\u001c\u0000"+
		"\u0000\u00f4;\u0001\u0000\u0000\u0000\u00f5\u0118\u0005\u0017\u0000\u0000"+
		"\u00f6\u00fb\u00034\u001a\u0000\u00f7\u00f8\u0005\u0012\u0000\u0000\u00f8"+
		"\u00fa\u00034\u001a\u0000\u00f9\u00f7\u0001\u0000\u0000\u0000\u00fa\u00fd"+
		"\u0001\u0000\u0000\u0000\u00fb\u00f9\u0001\u0000\u0000\u0000\u00fb\u00fc"+
		"\u0001\u0000\u0000\u0000\u00fc\u0119\u0001\u0000\u0000\u0000\u00fd\u00fb"+
		"\u0001\u0000\u0000\u0000\u00fe\u0103\u00036\u001b\u0000\u00ff\u0100\u0005"+
		"\u0012\u0000\u0000\u0100\u0102\u00036\u001b\u0000\u0101\u00ff\u0001\u0000"+
		"\u0000\u0000\u0102\u0105\u0001\u0000\u0000\u0000\u0103\u0101\u0001\u0000"+
		"\u0000\u0000\u0103\u0104\u0001\u0000\u0000\u0000\u0104\u0119\u0001\u0000"+
		"\u0000\u0000\u0105\u0103\u0001\u0000\u0000\u0000\u0106\u010b\u00038\u001c"+
		"\u0000\u0107\u0108\u0005\u0012\u0000\u0000\u0108\u010a\u00038\u001c\u0000"+
		"\u0109\u0107\u0001\u0000\u0000\u0000\u010a\u010d\u0001\u0000\u0000\u0000"+
		"\u010b\u0109\u0001\u0000\u0000\u0000\u010b\u010c\u0001\u0000\u0000\u0000"+
		"\u010c\u0117\u0001\u0000\u0000\u0000\u010d\u010b\u0001\u0000\u0000\u0000"+
		"\u010e\u0113\u0003:\u001d\u0000\u010f\u0110\u0005\u0012\u0000\u0000\u0110"+
		"\u0112\u0003:\u001d\u0000\u0111\u010f\u0001\u0000\u0000\u0000\u0112\u0115"+
		"\u0001\u0000\u0000\u0000\u0113\u0111\u0001\u0000\u0000\u0000\u0113\u0114"+
		"\u0001\u0000\u0000\u0000\u0114\u0117\u0001\u0000\u0000\u0000\u0115\u0113"+
		"\u0001\u0000\u0000\u0000\u0116\u0106\u0001\u0000\u0000\u0000\u0116\u010e"+
		"\u0001\u0000\u0000\u0000\u0117\u0119\u0001\u0000\u0000\u0000\u0118\u00f6"+
		"\u0001\u0000\u0000\u0000\u0118\u00fe\u0001\u0000\u0000\u0000\u0118\u0116"+
		"\u0001\u0000\u0000\u0000\u0119\u011a\u0001\u0000\u0000\u0000\u011a\u011b"+
		"\u0005\u0018\u0000\u0000\u011b=\u0001\u0000\u0000\u0000\u011c\u0121\u0003"+
		"@ \u0000\u011d\u011e\u0005\u0012\u0000\u0000\u011e\u0120\u0003@ \u0000"+
		"\u011f\u011d\u0001\u0000\u0000\u0000\u0120\u0123\u0001\u0000\u0000\u0000"+
		"\u0121\u011f\u0001\u0000\u0000\u0000\u0121\u0122\u0001\u0000\u0000\u0000"+
		"\u0122?\u0001\u0000\u0000\u0000\u0123\u0121\u0001\u0000\u0000\u0000\u0124"+
		"\u0125\u0005\u001d\u0000\u0000\u0125A\u0001\u0000\u0000\u0000\u0018CM"+
		"Xaix\u0080\u008d\u0096\u009b\u00a1\u00a9\u00b4\u00bc\u00c6\u00e1\u00e5"+
		"\u00fb\u0103\u010b\u0113\u0116\u0118\u0121";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}