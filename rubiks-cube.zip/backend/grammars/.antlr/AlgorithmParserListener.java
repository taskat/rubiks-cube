// Generated from d:/egyetem/msc/dipterv/rubiks-cube/backend/grammars/AlgorithmParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link AlgorithmParser}.
 */
public interface AlgorithmParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#algorithmFile}.
	 * @param ctx the parse tree
	 */
	void enterAlgorithmFile(AlgorithmParser.AlgorithmFileContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#algorithmFile}.
	 * @param ctx the parse tree
	 */
	void exitAlgorithmFile(AlgorithmParser.AlgorithmFileContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#helpers}.
	 * @param ctx the parse tree
	 */
	void enterHelpers(AlgorithmParser.HelpersContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#helpers}.
	 * @param ctx the parse tree
	 */
	void exitHelpers(AlgorithmParser.HelpersContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#helperLine}.
	 * @param ctx the parse tree
	 */
	void enterHelperLine(AlgorithmParser.HelperLineContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#helperLine}.
	 * @param ctx the parse tree
	 */
	void exitHelperLine(AlgorithmParser.HelperLineContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#steps}.
	 * @param ctx the parse tree
	 */
	void enterSteps(AlgorithmParser.StepsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#steps}.
	 * @param ctx the parse tree
	 */
	void exitSteps(AlgorithmParser.StepsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#step}.
	 * @param ctx the parse tree
	 */
	void enterStep(AlgorithmParser.StepContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#step}.
	 * @param ctx the parse tree
	 */
	void exitStep(AlgorithmParser.StepContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#stepLine}.
	 * @param ctx the parse tree
	 */
	void enterStepLine(AlgorithmParser.StepLineContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#stepLine}.
	 * @param ctx the parse tree
	 */
	void exitStepLine(AlgorithmParser.StepLineContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#goal}.
	 * @param ctx the parse tree
	 */
	void enterGoal(AlgorithmParser.GoalContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#goal}.
	 * @param ctx the parse tree
	 */
	void exitGoal(AlgorithmParser.GoalContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#runs}.
	 * @param ctx the parse tree
	 */
	void enterRuns(AlgorithmParser.RunsContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#runs}.
	 * @param ctx the parse tree
	 */
	void exitRuns(AlgorithmParser.RunsContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#branches}.
	 * @param ctx the parse tree
	 */
	void enterBranches(AlgorithmParser.BranchesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#branches}.
	 * @param ctx the parse tree
	 */
	void exitBranches(AlgorithmParser.BranchesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#doDef}.
	 * @param ctx the parse tree
	 */
	void enterDoDef(AlgorithmParser.DoDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#doDef}.
	 * @param ctx the parse tree
	 */
	void exitDoDef(AlgorithmParser.DoDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#branch}.
	 * @param ctx the parse tree
	 */
	void enterBranch(AlgorithmParser.BranchContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#branch}.
	 * @param ctx the parse tree
	 */
	void exitBranch(AlgorithmParser.BranchContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#ifBranch}.
	 * @param ctx the parse tree
	 */
	void enterIfBranch(AlgorithmParser.IfBranchContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#ifBranch}.
	 * @param ctx the parse tree
	 */
	void exitIfBranch(AlgorithmParser.IfBranchContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#prepareBranch}.
	 * @param ctx the parse tree
	 */
	void enterPrepareBranch(AlgorithmParser.PrepareBranchContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#prepareBranch}.
	 * @param ctx the parse tree
	 */
	void exitPrepareBranch(AlgorithmParser.PrepareBranchContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#consecutive}.
	 * @param ctx the parse tree
	 */
	void enterConsecutive(AlgorithmParser.ConsecutiveContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#consecutive}.
	 * @param ctx the parse tree
	 */
	void exitConsecutive(AlgorithmParser.ConsecutiveContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#algorithm}.
	 * @param ctx the parse tree
	 */
	void enterAlgorithm(AlgorithmParser.AlgorithmContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#algorithm}.
	 * @param ctx the parse tree
	 */
	void exitAlgorithm(AlgorithmParser.AlgorithmContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#turn}.
	 * @param ctx the parse tree
	 */
	void enterTurn(AlgorithmParser.TurnContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#turn}.
	 * @param ctx the parse tree
	 */
	void exitTurn(AlgorithmParser.TurnContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#boolExpr}.
	 * @param ctx the parse tree
	 */
	void enterBoolExpr(AlgorithmParser.BoolExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#boolExpr}.
	 * @param ctx the parse tree
	 */
	void exitBoolExpr(AlgorithmParser.BoolExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(AlgorithmParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#unaryOp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(AlgorithmParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp(AlgorithmParser.BinaryOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#binaryOp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp(AlgorithmParser.BinaryOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterExpr(AlgorithmParser.ExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitExpr(AlgorithmParser.ExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#unaryExpr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpr(AlgorithmParser.UnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#unaryExpr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpr(AlgorithmParser.UnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#binaryExpr}.
	 * @param ctx the parse tree
	 */
	void enterBinaryExpr(AlgorithmParser.BinaryExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#binaryExpr}.
	 * @param ctx the parse tree
	 */
	void exitBinaryExpr(AlgorithmParser.BinaryExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#functionalExpr}.
	 * @param ctx the parse tree
	 */
	void enterFunctionalExpr(AlgorithmParser.FunctionalExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#functionalExpr}.
	 * @param ctx the parse tree
	 */
	void exitFunctionalExpr(AlgorithmParser.FunctionalExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#function}.
	 * @param ctx the parse tree
	 */
	void enterFunction(AlgorithmParser.FunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#function}.
	 * @param ctx the parse tree
	 */
	void exitFunction(AlgorithmParser.FunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#parameter}.
	 * @param ctx the parse tree
	 */
	void enterParameter(AlgorithmParser.ParameterContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#parameter}.
	 * @param ctx the parse tree
	 */
	void exitParameter(AlgorithmParser.ParameterContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#singleNode}.
	 * @param ctx the parse tree
	 */
	void enterSingleNode(AlgorithmParser.SingleNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#singleNode}.
	 * @param ctx the parse tree
	 */
	void exitSingleNode(AlgorithmParser.SingleNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#node}.
	 * @param ctx the parse tree
	 */
	void enterNode(AlgorithmParser.NodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#node}.
	 * @param ctx the parse tree
	 */
	void exitNode(AlgorithmParser.NodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#piece}.
	 * @param ctx the parse tree
	 */
	void enterPiece(AlgorithmParser.PieceContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#piece}.
	 * @param ctx the parse tree
	 */
	void exitPiece(AlgorithmParser.PieceContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#position}.
	 * @param ctx the parse tree
	 */
	void enterPosition(AlgorithmParser.PositionContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#position}.
	 * @param ctx the parse tree
	 */
	void exitPosition(AlgorithmParser.PositionContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#coord}.
	 * @param ctx the parse tree
	 */
	void enterCoord(AlgorithmParser.CoordContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#coord}.
	 * @param ctx the parse tree
	 */
	void exitCoord(AlgorithmParser.CoordContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(AlgorithmParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(AlgorithmParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#sides}.
	 * @param ctx the parse tree
	 */
	void enterSides(AlgorithmParser.SidesContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#sides}.
	 * @param ctx the parse tree
	 */
	void exitSides(AlgorithmParser.SidesContext ctx);
	/**
	 * Enter a parse tree produced by {@link AlgorithmParser#side}.
	 * @param ctx the parse tree
	 */
	void enterSide(AlgorithmParser.SideContext ctx);
	/**
	 * Exit a parse tree produced by {@link AlgorithmParser#side}.
	 * @param ctx the parse tree
	 */
	void exitSide(AlgorithmParser.SideContext ctx);
}