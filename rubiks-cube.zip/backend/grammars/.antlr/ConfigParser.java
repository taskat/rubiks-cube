// Generated from d:/egyetem/msc/dipterv/rubiks-cube/backend/grammars/ConfigParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class ConfigParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ADVANCED=1, BACK=2, BEGINNER=3, CORNERS=4, CUBE=5, DOWN=6, EDGES=7, FRONT=8, 
		LEFT=9, MIDDLE=10, PUZZLE=11, RANDOM=12, RIGHT=13, SIZE=14, STATE=15, 
		STATE_DESCRIPTION=16, UP=17, LCURLY=18, RCURLY=19, LBRACKET=20, RBRACKET=21, 
		LPAREN=22, RPAREN=23, COLON=24, NUMBER=25, WORD=26, LINE_COMMENT=27, WS=28;
	public static final int
		RULE_configFile = 0, RULE_configLine = 1, RULE_puzzleTypeDef = 2, RULE_puzzleType = 3, 
		RULE_sizeDef = 4, RULE_stateDescriptionDef = 5, RULE_stateDescription = 6, 
		RULE_stateDef = 7, RULE_state = 8, RULE_beginnerState = 9, RULE_side = 10, 
		RULE_sideDef = 11, RULE_color = 12, RULE_advancedState = 13, RULE_corners = 14, 
		RULE_cornerLayer = 15, RULE_layerDef = 16, RULE_corner = 17, RULE_edges = 18, 
		RULE_edgeLayer = 19, RULE_edge = 20;
	private static String[] makeRuleNames() {
		return new String[] {
			"configFile", "configLine", "puzzleTypeDef", "puzzleType", "sizeDef", 
			"stateDescriptionDef", "stateDescription", "stateDef", "state", "beginnerState", 
			"side", "sideDef", "color", "advancedState", "corners", "cornerLayer", 
			"layerDef", "corner", "edges", "edgeLayer", "edge"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'advanced'", "'Back'", "'beginner'", "'corners'", "'cube'", "'Down'", 
			"'edges'", "'Front'", "'Left'", "'Middle'", "'puzzle'", "'random'", "'Right'", 
			"'size'", "'state'", "'state description'", "'Up'", "'{'", "'}'", "'['", 
			"']'", "'('", "')'", "':'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ADVANCED", "BACK", "BEGINNER", "CORNERS", "CUBE", "DOWN", "EDGES", 
			"FRONT", "LEFT", "MIDDLE", "PUZZLE", "RANDOM", "RIGHT", "SIZE", "STATE", 
			"STATE_DESCRIPTION", "UP", "LCURLY", "RCURLY", "LBRACKET", "RBRACKET", 
			"LPAREN", "RPAREN", "COLON", "NUMBER", "WORD", "LINE_COMMENT", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "ConfigParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public ConfigParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConfigFileContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(ConfigParser.EOF, 0); }
		public List<ConfigLineContext> configLine() {
			return getRuleContexts(ConfigLineContext.class);
		}
		public ConfigLineContext configLine(int i) {
			return getRuleContext(ConfigLineContext.class,i);
		}
		public ConfigFileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_configFile; }
	}

	public final ConfigFileContext configFile() throws RecognitionException {
		ConfigFileContext _localctx = new ConfigFileContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_configFile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(45);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 116736L) != 0)) {
				{
				{
				setState(42);
				configLine();
				}
				}
				setState(47);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(48);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConfigLineContext extends ParserRuleContext {
		public PuzzleTypeDefContext puzzleTypeDef() {
			return getRuleContext(PuzzleTypeDefContext.class,0);
		}
		public SizeDefContext sizeDef() {
			return getRuleContext(SizeDefContext.class,0);
		}
		public StateDescriptionDefContext stateDescriptionDef() {
			return getRuleContext(StateDescriptionDefContext.class,0);
		}
		public StateDefContext stateDef() {
			return getRuleContext(StateDefContext.class,0);
		}
		public ConfigLineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_configLine; }
	}

	public final ConfigLineContext configLine() throws RecognitionException {
		ConfigLineContext _localctx = new ConfigLineContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_configLine);
		try {
			setState(54);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case PUZZLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(50);
				puzzleTypeDef();
				}
				break;
			case SIZE:
				enterOuterAlt(_localctx, 2);
				{
				setState(51);
				sizeDef();
				}
				break;
			case STATE_DESCRIPTION:
				enterOuterAlt(_localctx, 3);
				{
				setState(52);
				stateDescriptionDef();
				}
				break;
			case STATE:
				enterOuterAlt(_localctx, 4);
				{
				setState(53);
				stateDef();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PuzzleTypeDefContext extends ParserRuleContext {
		public TerminalNode PUZZLE() { return getToken(ConfigParser.PUZZLE, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public PuzzleTypeContext puzzleType() {
			return getRuleContext(PuzzleTypeContext.class,0);
		}
		public PuzzleTypeDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_puzzleTypeDef; }
	}

	public final PuzzleTypeDefContext puzzleTypeDef() throws RecognitionException {
		PuzzleTypeDefContext _localctx = new PuzzleTypeDefContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_puzzleTypeDef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(56);
			match(PUZZLE);
			setState(57);
			match(COLON);
			setState(58);
			puzzleType();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PuzzleTypeContext extends ParserRuleContext {
		public TerminalNode CUBE() { return getToken(ConfigParser.CUBE, 0); }
		public PuzzleTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_puzzleType; }
	}

	public final PuzzleTypeContext puzzleType() throws RecognitionException {
		PuzzleTypeContext _localctx = new PuzzleTypeContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_puzzleType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			match(CUBE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SizeDefContext extends ParserRuleContext {
		public TerminalNode SIZE() { return getToken(ConfigParser.SIZE, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public TerminalNode NUMBER() { return getToken(ConfigParser.NUMBER, 0); }
		public SizeDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sizeDef; }
	}

	public final SizeDefContext sizeDef() throws RecognitionException {
		SizeDefContext _localctx = new SizeDefContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_sizeDef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(62);
			match(SIZE);
			setState(63);
			match(COLON);
			setState(64);
			match(NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StateDescriptionDefContext extends ParserRuleContext {
		public TerminalNode STATE_DESCRIPTION() { return getToken(ConfigParser.STATE_DESCRIPTION, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public StateDescriptionContext stateDescription() {
			return getRuleContext(StateDescriptionContext.class,0);
		}
		public StateDescriptionDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stateDescriptionDef; }
	}

	public final StateDescriptionDefContext stateDescriptionDef() throws RecognitionException {
		StateDescriptionDefContext _localctx = new StateDescriptionDefContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_stateDescriptionDef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(66);
			match(STATE_DESCRIPTION);
			setState(67);
			match(COLON);
			setState(68);
			stateDescription();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StateDescriptionContext extends ParserRuleContext {
		public TerminalNode BEGINNER() { return getToken(ConfigParser.BEGINNER, 0); }
		public TerminalNode ADVANCED() { return getToken(ConfigParser.ADVANCED, 0); }
		public StateDescriptionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stateDescription; }
	}

	public final StateDescriptionContext stateDescription() throws RecognitionException {
		StateDescriptionContext _localctx = new StateDescriptionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_stateDescription);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(70);
			_la = _input.LA(1);
			if ( !(_la==ADVANCED || _la==BEGINNER) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StateDefContext extends ParserRuleContext {
		public TerminalNode STATE() { return getToken(ConfigParser.STATE, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public StateContext state() {
			return getRuleContext(StateContext.class,0);
		}
		public StateDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stateDef; }
	}

	public final StateDefContext stateDef() throws RecognitionException {
		StateDefContext _localctx = new StateDefContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_stateDef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(72);
			match(STATE);
			setState(73);
			match(COLON);
			setState(74);
			state();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StateContext extends ParserRuleContext {
		public TerminalNode RANDOM() { return getToken(ConfigParser.RANDOM, 0); }
		public BeginnerStateContext beginnerState() {
			return getRuleContext(BeginnerStateContext.class,0);
		}
		public AdvancedStateContext advancedState() {
			return getRuleContext(AdvancedStateContext.class,0);
		}
		public StateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state; }
	}

	public final StateContext state() throws RecognitionException {
		StateContext _localctx = new StateContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_state);
		try {
			setState(79);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RANDOM:
				enterOuterAlt(_localctx, 1);
				{
				setState(76);
				match(RANDOM);
				}
				break;
			case BACK:
			case DOWN:
			case FRONT:
			case LEFT:
			case RIGHT:
			case UP:
				enterOuterAlt(_localctx, 2);
				{
				setState(77);
				beginnerState();
				}
				break;
			case CORNERS:
			case EDGES:
				enterOuterAlt(_localctx, 3);
				{
				setState(78);
				advancedState();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BeginnerStateContext extends ParserRuleContext {
		public List<SideContext> side() {
			return getRuleContexts(SideContext.class);
		}
		public SideContext side(int i) {
			return getRuleContext(SideContext.class,i);
		}
		public BeginnerStateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_beginnerState; }
	}

	public final BeginnerStateContext beginnerState() throws RecognitionException {
		BeginnerStateContext _localctx = new BeginnerStateContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_beginnerState);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(81);
				side();
				}
				}
				setState(84); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 140100L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SideContext extends ParserRuleContext {
		public SideDefContext sideDef() {
			return getRuleContext(SideDefContext.class,0);
		}
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public List<ColorContext> color() {
			return getRuleContexts(ColorContext.class);
		}
		public ColorContext color(int i) {
			return getRuleContext(ColorContext.class,i);
		}
		public SideContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_side; }
	}

	public final SideContext side() throws RecognitionException {
		SideContext _localctx = new SideContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_side);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(86);
			sideDef();
			setState(87);
			match(COLON);
			setState(89); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(88);
				color();
				}
				}
				setState(91); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WORD );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SideDefContext extends ParserRuleContext {
		public TerminalNode FRONT() { return getToken(ConfigParser.FRONT, 0); }
		public TerminalNode BACK() { return getToken(ConfigParser.BACK, 0); }
		public TerminalNode LEFT() { return getToken(ConfigParser.LEFT, 0); }
		public TerminalNode RIGHT() { return getToken(ConfigParser.RIGHT, 0); }
		public TerminalNode UP() { return getToken(ConfigParser.UP, 0); }
		public TerminalNode DOWN() { return getToken(ConfigParser.DOWN, 0); }
		public SideDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sideDef; }
	}

	public final SideDefContext sideDef() throws RecognitionException {
		SideDefContext _localctx = new SideDefContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_sideDef);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(93);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 140100L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ColorContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(ConfigParser.WORD, 0); }
		public ColorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_color; }
	}

	public final ColorContext color() throws RecognitionException {
		ColorContext _localctx = new ColorContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_color);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AdvancedStateContext extends ParserRuleContext {
		public CornersContext corners() {
			return getRuleContext(CornersContext.class,0);
		}
		public EdgesContext edges() {
			return getRuleContext(EdgesContext.class,0);
		}
		public AdvancedStateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_advancedState; }
	}

	public final AdvancedStateContext advancedState() throws RecognitionException {
		AdvancedStateContext _localctx = new AdvancedStateContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_advancedState);
		try {
			setState(104);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(97);
				corners();
				setState(98);
				edges();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(100);
				edges();
				setState(101);
				corners();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(103);
				corners();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CornersContext extends ParserRuleContext {
		public TerminalNode CORNERS() { return getToken(ConfigParser.CORNERS, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public List<CornerLayerContext> cornerLayer() {
			return getRuleContexts(CornerLayerContext.class);
		}
		public CornerLayerContext cornerLayer(int i) {
			return getRuleContext(CornerLayerContext.class,i);
		}
		public CornersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_corners; }
	}

	public final CornersContext corners() throws RecognitionException {
		CornersContext _localctx = new CornersContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_corners);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(106);
			match(CORNERS);
			setState(107);
			match(COLON);
			setState(109); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(108);
				cornerLayer();
				}
				}
				setState(111); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 132160L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CornerLayerContext extends ParserRuleContext {
		public LayerDefContext layerDef() {
			return getRuleContext(LayerDefContext.class,0);
		}
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public List<CornerContext> corner() {
			return getRuleContexts(CornerContext.class);
		}
		public CornerContext corner(int i) {
			return getRuleContext(CornerContext.class,i);
		}
		public CornerLayerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cornerLayer; }
	}

	public final CornerLayerContext cornerLayer() throws RecognitionException {
		CornerLayerContext _localctx = new CornerLayerContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_cornerLayer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113);
			layerDef();
			setState(114);
			match(COLON);
			setState(116); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(115);
				corner();
				}
				}
				setState(118); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WORD );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LayerDefContext extends ParserRuleContext {
		public TerminalNode UP() { return getToken(ConfigParser.UP, 0); }
		public TerminalNode MIDDLE() { return getToken(ConfigParser.MIDDLE, 0); }
		public TerminalNode DOWN() { return getToken(ConfigParser.DOWN, 0); }
		public LayerDefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_layerDef; }
	}

	public final LayerDefContext layerDef() throws RecognitionException {
		LayerDefContext _localctx = new LayerDefContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_layerDef);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(120);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 132160L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CornerContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(ConfigParser.WORD, 0); }
		public CornerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_corner; }
	}

	public final CornerContext corner() throws RecognitionException {
		CornerContext _localctx = new CornerContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_corner);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(122);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EdgesContext extends ParserRuleContext {
		public TerminalNode EDGES() { return getToken(ConfigParser.EDGES, 0); }
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public List<EdgeLayerContext> edgeLayer() {
			return getRuleContexts(EdgeLayerContext.class);
		}
		public EdgeLayerContext edgeLayer(int i) {
			return getRuleContext(EdgeLayerContext.class,i);
		}
		public EdgesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_edges; }
	}

	public final EdgesContext edges() throws RecognitionException {
		EdgesContext _localctx = new EdgesContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_edges);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(124);
			match(EDGES);
			setState(125);
			match(COLON);
			setState(127); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(126);
				edgeLayer();
				}
				}
				setState(129); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 132160L) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EdgeLayerContext extends ParserRuleContext {
		public LayerDefContext layerDef() {
			return getRuleContext(LayerDefContext.class,0);
		}
		public TerminalNode COLON() { return getToken(ConfigParser.COLON, 0); }
		public List<EdgeContext> edge() {
			return getRuleContexts(EdgeContext.class);
		}
		public EdgeContext edge(int i) {
			return getRuleContext(EdgeContext.class,i);
		}
		public EdgeLayerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_edgeLayer; }
	}

	public final EdgeLayerContext edgeLayer() throws RecognitionException {
		EdgeLayerContext _localctx = new EdgeLayerContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_edgeLayer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(131);
			layerDef();
			setState(132);
			match(COLON);
			setState(134); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(133);
				edge();
				}
				}
				setState(136); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==WORD );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EdgeContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(ConfigParser.WORD, 0); }
		public EdgeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_edge; }
	}

	public final EdgeContext edge() throws RecognitionException {
		EdgeContext _localctx = new EdgeContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_edge);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(138);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u001c\u008d\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0001\u0000\u0005"+
		"\u0000,\b\u0000\n\u0000\f\u0000/\t\u0000\u0001\u0000\u0001\u0000\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u00017\b\u0001\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003\u0001"+
		"\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001"+
		"\u0007\u0001\u0007\u0001\b\u0001\b\u0001\b\u0003\bP\b\b\u0001\t\u0004"+
		"\tS\b\t\u000b\t\f\tT\u0001\n\u0001\n\u0001\n\u0004\nZ\b\n\u000b\n\f\n"+
		"[\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0003\ri\b\r\u0001\u000e\u0001\u000e\u0001"+
		"\u000e\u0004\u000en\b\u000e\u000b\u000e\f\u000eo\u0001\u000f\u0001\u000f"+
		"\u0001\u000f\u0004\u000fu\b\u000f\u000b\u000f\f\u000fv\u0001\u0010\u0001"+
		"\u0010\u0001\u0011\u0001\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0004"+
		"\u0012\u0080\b\u0012\u000b\u0012\f\u0012\u0081\u0001\u0013\u0001\u0013"+
		"\u0001\u0013\u0004\u0013\u0087\b\u0013\u000b\u0013\f\u0013\u0088\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0000\u0000\u0015\u0000\u0002\u0004\u0006"+
		"\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u001e \"$&(\u0000"+
		"\u0003\u0002\u0000\u0001\u0001\u0003\u0003\u0005\u0000\u0002\u0002\u0006"+
		"\u0006\b\t\r\r\u0011\u0011\u0003\u0000\u0006\u0006\n\n\u0011\u0011\u0085"+
		"\u0000-\u0001\u0000\u0000\u0000\u00026\u0001\u0000\u0000\u0000\u00048"+
		"\u0001\u0000\u0000\u0000\u0006<\u0001\u0000\u0000\u0000\b>\u0001\u0000"+
		"\u0000\u0000\nB\u0001\u0000\u0000\u0000\fF\u0001\u0000\u0000\u0000\u000e"+
		"H\u0001\u0000\u0000\u0000\u0010O\u0001\u0000\u0000\u0000\u0012R\u0001"+
		"\u0000\u0000\u0000\u0014V\u0001\u0000\u0000\u0000\u0016]\u0001\u0000\u0000"+
		"\u0000\u0018_\u0001\u0000\u0000\u0000\u001ah\u0001\u0000\u0000\u0000\u001c"+
		"j\u0001\u0000\u0000\u0000\u001eq\u0001\u0000\u0000\u0000 x\u0001\u0000"+
		"\u0000\u0000\"z\u0001\u0000\u0000\u0000$|\u0001\u0000\u0000\u0000&\u0083"+
		"\u0001\u0000\u0000\u0000(\u008a\u0001\u0000\u0000\u0000*,\u0003\u0002"+
		"\u0001\u0000+*\u0001\u0000\u0000\u0000,/\u0001\u0000\u0000\u0000-+\u0001"+
		"\u0000\u0000\u0000-.\u0001\u0000\u0000\u0000.0\u0001\u0000\u0000\u0000"+
		"/-\u0001\u0000\u0000\u000001\u0005\u0000\u0000\u00011\u0001\u0001\u0000"+
		"\u0000\u000027\u0003\u0004\u0002\u000037\u0003\b\u0004\u000047\u0003\n"+
		"\u0005\u000057\u0003\u000e\u0007\u000062\u0001\u0000\u0000\u000063\u0001"+
		"\u0000\u0000\u000064\u0001\u0000\u0000\u000065\u0001\u0000\u0000\u0000"+
		"7\u0003\u0001\u0000\u0000\u000089\u0005\u000b\u0000\u00009:\u0005\u0018"+
		"\u0000\u0000:;\u0003\u0006\u0003\u0000;\u0005\u0001\u0000\u0000\u0000"+
		"<=\u0005\u0005\u0000\u0000=\u0007\u0001\u0000\u0000\u0000>?\u0005\u000e"+
		"\u0000\u0000?@\u0005\u0018\u0000\u0000@A\u0005\u0019\u0000\u0000A\t\u0001"+
		"\u0000\u0000\u0000BC\u0005\u0010\u0000\u0000CD\u0005\u0018\u0000\u0000"+
		"DE\u0003\f\u0006\u0000E\u000b\u0001\u0000\u0000\u0000FG\u0007\u0000\u0000"+
		"\u0000G\r\u0001\u0000\u0000\u0000HI\u0005\u000f\u0000\u0000IJ\u0005\u0018"+
		"\u0000\u0000JK\u0003\u0010\b\u0000K\u000f\u0001\u0000\u0000\u0000LP\u0005"+
		"\f\u0000\u0000MP\u0003\u0012\t\u0000NP\u0003\u001a\r\u0000OL\u0001\u0000"+
		"\u0000\u0000OM\u0001\u0000\u0000\u0000ON\u0001\u0000\u0000\u0000P\u0011"+
		"\u0001\u0000\u0000\u0000QS\u0003\u0014\n\u0000RQ\u0001\u0000\u0000\u0000"+
		"ST\u0001\u0000\u0000\u0000TR\u0001\u0000\u0000\u0000TU\u0001\u0000\u0000"+
		"\u0000U\u0013\u0001\u0000\u0000\u0000VW\u0003\u0016\u000b\u0000WY\u0005"+
		"\u0018\u0000\u0000XZ\u0003\u0018\f\u0000YX\u0001\u0000\u0000\u0000Z[\u0001"+
		"\u0000\u0000\u0000[Y\u0001\u0000\u0000\u0000[\\\u0001\u0000\u0000\u0000"+
		"\\\u0015\u0001\u0000\u0000\u0000]^\u0007\u0001\u0000\u0000^\u0017\u0001"+
		"\u0000\u0000\u0000_`\u0005\u001a\u0000\u0000`\u0019\u0001\u0000\u0000"+
		"\u0000ab\u0003\u001c\u000e\u0000bc\u0003$\u0012\u0000ci\u0001\u0000\u0000"+
		"\u0000de\u0003$\u0012\u0000ef\u0003\u001c\u000e\u0000fi\u0001\u0000\u0000"+
		"\u0000gi\u0003\u001c\u000e\u0000ha\u0001\u0000\u0000\u0000hd\u0001\u0000"+
		"\u0000\u0000hg\u0001\u0000\u0000\u0000i\u001b\u0001\u0000\u0000\u0000"+
		"jk\u0005\u0004\u0000\u0000km\u0005\u0018\u0000\u0000ln\u0003\u001e\u000f"+
		"\u0000ml\u0001\u0000\u0000\u0000no\u0001\u0000\u0000\u0000om\u0001\u0000"+
		"\u0000\u0000op\u0001\u0000\u0000\u0000p\u001d\u0001\u0000\u0000\u0000"+
		"qr\u0003 \u0010\u0000rt\u0005\u0018\u0000\u0000su\u0003\"\u0011\u0000"+
		"ts\u0001\u0000\u0000\u0000uv\u0001\u0000\u0000\u0000vt\u0001\u0000\u0000"+
		"\u0000vw\u0001\u0000\u0000\u0000w\u001f\u0001\u0000\u0000\u0000xy\u0007"+
		"\u0002\u0000\u0000y!\u0001\u0000\u0000\u0000z{\u0005\u001a\u0000\u0000"+
		"{#\u0001\u0000\u0000\u0000|}\u0005\u0007\u0000\u0000}\u007f\u0005\u0018"+
		"\u0000\u0000~\u0080\u0003&\u0013\u0000\u007f~\u0001\u0000\u0000\u0000"+
		"\u0080\u0081\u0001\u0000\u0000\u0000\u0081\u007f\u0001\u0000\u0000\u0000"+
		"\u0081\u0082\u0001\u0000\u0000\u0000\u0082%\u0001\u0000\u0000\u0000\u0083"+
		"\u0084\u0003 \u0010\u0000\u0084\u0086\u0005\u0018\u0000\u0000\u0085\u0087"+
		"\u0003(\u0014\u0000\u0086\u0085\u0001\u0000\u0000\u0000\u0087\u0088\u0001"+
		"\u0000\u0000\u0000\u0088\u0086\u0001\u0000\u0000\u0000\u0088\u0089\u0001"+
		"\u0000\u0000\u0000\u0089\'\u0001\u0000\u0000\u0000\u008a\u008b\u0005\u001a"+
		"\u0000\u0000\u008b)\u0001\u0000\u0000\u0000\n-6OT[hov\u0081\u0088";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}