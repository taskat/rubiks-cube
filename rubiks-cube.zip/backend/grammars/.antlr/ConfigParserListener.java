// Generated from d:/egyetem/msc/dipterv/rubiks-cube/backend/grammars/ConfigParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link ConfigParser}.
 */
public interface ConfigParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link ConfigParser#configFile}.
	 * @param ctx the parse tree
	 */
	void enterConfigFile(ConfigParser.ConfigFileContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#configFile}.
	 * @param ctx the parse tree
	 */
	void exitConfigFile(ConfigParser.ConfigFileContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#configLine}.
	 * @param ctx the parse tree
	 */
	void enterConfigLine(ConfigParser.ConfigLineContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#configLine}.
	 * @param ctx the parse tree
	 */
	void exitConfigLine(ConfigParser.ConfigLineContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#puzzleTypeDef}.
	 * @param ctx the parse tree
	 */
	void enterPuzzleTypeDef(ConfigParser.PuzzleTypeDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#puzzleTypeDef}.
	 * @param ctx the parse tree
	 */
	void exitPuzzleTypeDef(ConfigParser.PuzzleTypeDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#puzzleType}.
	 * @param ctx the parse tree
	 */
	void enterPuzzleType(ConfigParser.PuzzleTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#puzzleType}.
	 * @param ctx the parse tree
	 */
	void exitPuzzleType(ConfigParser.PuzzleTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#sizeDef}.
	 * @param ctx the parse tree
	 */
	void enterSizeDef(ConfigParser.SizeDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#sizeDef}.
	 * @param ctx the parse tree
	 */
	void exitSizeDef(ConfigParser.SizeDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#stateDescriptionDef}.
	 * @param ctx the parse tree
	 */
	void enterStateDescriptionDef(ConfigParser.StateDescriptionDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#stateDescriptionDef}.
	 * @param ctx the parse tree
	 */
	void exitStateDescriptionDef(ConfigParser.StateDescriptionDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#stateDescription}.
	 * @param ctx the parse tree
	 */
	void enterStateDescription(ConfigParser.StateDescriptionContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#stateDescription}.
	 * @param ctx the parse tree
	 */
	void exitStateDescription(ConfigParser.StateDescriptionContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#stateDef}.
	 * @param ctx the parse tree
	 */
	void enterStateDef(ConfigParser.StateDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#stateDef}.
	 * @param ctx the parse tree
	 */
	void exitStateDef(ConfigParser.StateDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#state}.
	 * @param ctx the parse tree
	 */
	void enterState(ConfigParser.StateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#state}.
	 * @param ctx the parse tree
	 */
	void exitState(ConfigParser.StateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#beginnerState}.
	 * @param ctx the parse tree
	 */
	void enterBeginnerState(ConfigParser.BeginnerStateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#beginnerState}.
	 * @param ctx the parse tree
	 */
	void exitBeginnerState(ConfigParser.BeginnerStateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#side}.
	 * @param ctx the parse tree
	 */
	void enterSide(ConfigParser.SideContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#side}.
	 * @param ctx the parse tree
	 */
	void exitSide(ConfigParser.SideContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#sideDef}.
	 * @param ctx the parse tree
	 */
	void enterSideDef(ConfigParser.SideDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#sideDef}.
	 * @param ctx the parse tree
	 */
	void exitSideDef(ConfigParser.SideDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#color}.
	 * @param ctx the parse tree
	 */
	void enterColor(ConfigParser.ColorContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#color}.
	 * @param ctx the parse tree
	 */
	void exitColor(ConfigParser.ColorContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#advancedState}.
	 * @param ctx the parse tree
	 */
	void enterAdvancedState(ConfigParser.AdvancedStateContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#advancedState}.
	 * @param ctx the parse tree
	 */
	void exitAdvancedState(ConfigParser.AdvancedStateContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#corners}.
	 * @param ctx the parse tree
	 */
	void enterCorners(ConfigParser.CornersContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#corners}.
	 * @param ctx the parse tree
	 */
	void exitCorners(ConfigParser.CornersContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#cornerLayer}.
	 * @param ctx the parse tree
	 */
	void enterCornerLayer(ConfigParser.CornerLayerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#cornerLayer}.
	 * @param ctx the parse tree
	 */
	void exitCornerLayer(ConfigParser.CornerLayerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#layerDef}.
	 * @param ctx the parse tree
	 */
	void enterLayerDef(ConfigParser.LayerDefContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#layerDef}.
	 * @param ctx the parse tree
	 */
	void exitLayerDef(ConfigParser.LayerDefContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#corner}.
	 * @param ctx the parse tree
	 */
	void enterCorner(ConfigParser.CornerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#corner}.
	 * @param ctx the parse tree
	 */
	void exitCorner(ConfigParser.CornerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#edges}.
	 * @param ctx the parse tree
	 */
	void enterEdges(ConfigParser.EdgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#edges}.
	 * @param ctx the parse tree
	 */
	void exitEdges(ConfigParser.EdgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#edgeLayer}.
	 * @param ctx the parse tree
	 */
	void enterEdgeLayer(ConfigParser.EdgeLayerContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#edgeLayer}.
	 * @param ctx the parse tree
	 */
	void exitEdgeLayer(ConfigParser.EdgeLayerContext ctx);
	/**
	 * Enter a parse tree produced by {@link ConfigParser#edge}.
	 * @param ctx the parse tree
	 */
	void enterEdge(ConfigParser.EdgeContext ctx);
	/**
	 * Exit a parse tree produced by {@link ConfigParser#edge}.
	 * @param ctx the parse tree
	 */
	void exitEdge(ConfigParser.EdgeContext ctx);
}