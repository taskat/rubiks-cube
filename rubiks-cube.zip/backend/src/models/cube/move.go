package cube

type move struct {
	cycles []cycle
	steps  int
}
