package parameters

type List[P Parameter] []P
