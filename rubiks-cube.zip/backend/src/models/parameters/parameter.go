package parameters

type Parameter interface{}
