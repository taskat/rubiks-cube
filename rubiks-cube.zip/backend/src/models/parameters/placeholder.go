package parameters

type PlaceHolder struct{}
