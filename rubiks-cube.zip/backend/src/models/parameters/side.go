package parameters

type Side interface {
	String() string
}
