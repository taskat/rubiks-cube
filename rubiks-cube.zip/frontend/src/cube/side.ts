export enum Side {
    Up = "up",
    Down = "down",
    Left = "left",
    Right = "right",
    Front = "front",
    Back = "back",
    None = "none"
}