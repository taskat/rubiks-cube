import * as monaco from "monaco-editor";

export type State = monaco.editor.ICodeEditorViewState | null;