export enum Level {
    INFO = "INFO",
    WARNING = "WARNING",
    ERROR = "ERROR"
}